const gulp = require('gulp');

// Default task
gulp.task('default', [$1]);